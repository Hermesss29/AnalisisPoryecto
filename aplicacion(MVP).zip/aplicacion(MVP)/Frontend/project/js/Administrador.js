// Función para redirigir a la vista de Cursos
function redirectToCursos() {
    window.location.href = '../view/Curso.html';
}

// Función para redirigir a la vista de Materias
function redirectToMaterias() {
    window.location.href = '../view/Materia.html'; // Asegúrate de que esta página exista y tenga la ruta correcta
}

// Función para redirigir a la vista de Usuarios
function redirectToUsuarios() {
    window.location.href = '../view/Usuario.html'; // Asegúrate de que esta página exista y tenga la ruta correcta
}

// Función para redirigir a la vista de Personas
function redirectToPersonas() {
    window.location.href = '../view/Persona.html'; // Asegúrate de que esta página exista y tenga la ruta correcta
}

// Función para redirigir a la vista de Notas
function redirectToNotas() {
    window.location.href = '../view/Notas.html'; // Asegúrate de que esta página exista y tenga la ruta correcta
}

function redirectToRol() {
    window.location.href = '../view/Rol.html'; // Asegúrate de que esta página exista y tenga la ruta correcta
}
