// Función para redirigir a la página de subir notas
function subirNotas() {
    // Redirigir a la página Notas
    window.location.href = 'file:///D:/Escritorio/ArchivosUni/analisisSistemas/PlanillEscolarFront/view/Notas.html';
}

// Función para registrar la asistencia (Aún no implementado)
function registrarAsistencia() {
    // Aquí podrías implementar la lógica para registrar asistencia.
    // En este ejemplo solo mostramos una alerta.
    alert('Función de registrar asistencia aún no implementada.');
}
