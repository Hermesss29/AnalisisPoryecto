package com.corhuila.planillaescolar.repositories;

import com.corhuila.planillaescolar.entity.Curso;
import org.springframework.data.repository.CrudRepository;

public interface ICursoRepository extends CrudRepository<Curso,Long> {



}
