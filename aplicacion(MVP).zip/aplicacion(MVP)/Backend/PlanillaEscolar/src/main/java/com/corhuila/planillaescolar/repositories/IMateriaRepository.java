package com.corhuila.planillaescolar.repositories;

import com.corhuila.planillaescolar.entity.Materia;
import org.springframework.data.repository.CrudRepository;

public interface IMateriaRepository extends CrudRepository<Materia,Long> {



}
