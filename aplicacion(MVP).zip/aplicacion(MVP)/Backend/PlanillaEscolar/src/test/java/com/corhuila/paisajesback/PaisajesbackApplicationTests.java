package com.corhuila.paisajesback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaisajesbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
